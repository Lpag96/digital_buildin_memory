# Digital Building Memory — Complete MVP

Monolite modulare **Java 21 / Spring Boot 3.5 / Gradle / MySQL** con frontend Thymeleaf, backend REST e batch nello stesso progetto. È predisposto per Docker, ma non richiede Docker.

## Funzioni incluse
- multi-tenancy per organizzazione, login Spring Security, BCrypt, ruoli OWNER/ADMIN/EDITOR/VIEWER
- edifici, piani, ambienti, impianti, componenti e catalogo prodotti/DPP URI
- documenti collegati a edificio/componente, SHA-256, anti-duplicazione, storage filesystem tenant-safe
- estrazione locale testo PDF/TXT/CSV/JSON/XML/IFC e classificazione euristica; stato processing e batch retry
- import IFC come documento BIM indicizzabile (non è un editor BIM)
- garanzie, intervalli e scadenze manutenzione, storico interventi
- ricerca trasversale componenti/documenti e export CSV componenti
- dashboard web, download documenti autorizzato
- audit persistente MySQL + correlation ID + log JSON rolling; successi e fallimenti dei batch sono loggati
- Flyway V1/V2/V3, Actuator health/metrics, configurazione via environment

## Avvio MySQL
Eseguire `mysql-setup.sql` come amministratore MySQL. Poi:
```bash
export DB_URL='jdbc:mysql://localhost:3306/digital_building_memory?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC'
export DB_USERNAME=dbm_user
export DB_PASSWORD='cambia-questa-password'
export BOOTSTRAP_ADMIN_EMAIL='owner@example.com'
export BOOTSTRAP_ADMIN_PASSWORD='una-password-lunga-e-casuale'
export STORAGE_ROOT='./data/documents'
gradle bootRun
```
Aprire `http://localhost:8080/login`. Al primo avvio Flyway crea/migra lo schema e BootstrapAdmin crea l'OWNER solo se le variabili sono presenti.

## Build/test
```bash
gradle clean test
gradle bootJar
```

## API principali
`GET/POST /api/buildings`; `PUT /api/buildings/{id}`; `POST /api/buildings/{id}/floors`; `POST /api/floors/{id}/rooms`; `POST /api/buildings/{id}/systems`; `GET/POST /api/buildings/{id}/components`; `PUT /api/components/{id}`; `GET/POST /api/products`; multipart `POST /api/buildings/{id}/documents`; `GET /api/documents/{id}/download`; `POST /api/components/{id}/maintenance`; `GET /api/search?q=...`; `GET /api/exports/components.csv`; amministrazione `GET/POST /api/users`.

Le POST/PUT/PATCH richiedono CSRF quando invocate da browser/sessione. Per integrazioni machine-to-machine va aggiunto OAuth2/JWT/API-key gateway invece di disabilitare globalmente CSRF.

## Logging e audit
Ogni richiesta riceve `X-Correlation-ID`; se il client lo invia viene propagato. I log tecnici sono JSON su console/file con rolling policy. Eventi business/security sono scritti in `audit_events` con correlation ID, tenant, actor, outcome, IP e user-agent. Password/token e contenuto integrale dei documenti **non** vengono inseriti nei log.

## Limiti intenzionali
Questa è una release completa di MVP, non una certificazione normativa. Il DPP è modellato tramite identificatori/URI e documentazione; per integrazione col registro UE occorrerà implementare l'adapter verso le API ufficiali disponibili al momento del deployment. IFC viene archiviato/indicizzato ma non renderizzato in 3D. OCR immagini e LLM non sono inclusi per evitare dipendenze cloud/chiavi: `DocumentProcessingService` è il punto di estensione.
