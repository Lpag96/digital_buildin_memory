CREATE DATABASE IF NOT EXISTS digital_building_memory CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'dbm_user'@'localhost' IDENTIFIED BY 'change_me';
GRANT ALL PRIVILEGES ON digital_building_memory.* TO 'dbm_user'@'localhost';
FLUSH PRIVILEGES;
