ALTER TABLE buildings DROP INDEX external_code; CREATE UNIQUE INDEX uq_building_org_external_code ON buildings(organization_id, external_code);
