CREATE TABLE organizations (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, slug VARCHAR(120) NOT NULL UNIQUE,
 created_at TIMESTAMP(6) NOT NULL, updated_at TIMESTAMP(6) NOT NULL
);
CREATE TABLE app_users (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, organization_id BIGINT NOT NULL, email VARCHAR(320) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL, display_name VARCHAR(255) NOT NULL, role VARCHAR(30) NOT NULL,
 enabled BOOLEAN NOT NULL DEFAULT TRUE, last_login_at TIMESTAMP(6) NULL,
 created_at TIMESTAMP(6) NOT NULL, updated_at TIMESTAMP(6) NOT NULL,
 CONSTRAINT fk_user_org FOREIGN KEY(organization_id) REFERENCES organizations(id), INDEX idx_user_org(organization_id)
);
ALTER TABLE buildings ADD COLUMN organization_id BIGINT NULL AFTER id;
ALTER TABLE products ADD COLUMN organization_id BIGINT NULL AFTER id;
INSERT INTO organizations(name,slug,created_at,updated_at) VALUES ('Legacy Workspace','legacy',CURRENT_TIMESTAMP(6),CURRENT_TIMESTAMP(6));
UPDATE buildings SET organization_id=(SELECT id FROM organizations WHERE slug='legacy') WHERE organization_id IS NULL;
UPDATE products SET organization_id=(SELECT id FROM organizations WHERE slug='legacy') WHERE organization_id IS NULL;
ALTER TABLE buildings MODIFY organization_id BIGINT NOT NULL;
ALTER TABLE products MODIFY organization_id BIGINT NOT NULL;
ALTER TABLE buildings ADD CONSTRAINT fk_building_org FOREIGN KEY(organization_id) REFERENCES organizations(id), ADD INDEX idx_building_org(organization_id);
ALTER TABLE products ADD CONSTRAINT fk_product_org FOREIGN KEY(organization_id) REFERENCES organizations(id), ADD INDEX idx_product_org(organization_id);
ALTER TABLE audit_events ADD COLUMN organization_id BIGINT NULL AFTER id;
ALTER TABLE audit_events ADD COLUMN ip_address VARCHAR(64) NULL, ADD COLUMN user_agent VARCHAR(1000) NULL;
CREATE INDEX idx_audit_org_time ON audit_events(organization_id, occurred_at);
