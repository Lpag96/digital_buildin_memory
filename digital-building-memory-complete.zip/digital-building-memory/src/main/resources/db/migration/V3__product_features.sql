ALTER TABLE documents ADD COLUMN processing_status VARCHAR(30) NOT NULL DEFAULT 'PENDING', ADD COLUMN extracted_text LONGTEXT NULL, ADD COLUMN classification VARCHAR(100) NULL, ADD COLUMN processed_at TIMESTAMP(6) NULL;
ALTER TABLE components ADD COLUMN notes TEXT NULL, ADD COLUMN maintenance_interval_days INT NULL;
CREATE TABLE maintenance_events (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, component_id BIGINT NOT NULL, performed_at DATE NOT NULL, next_due_date DATE NULL,
 type VARCHAR(100) NOT NULL, notes TEXT NULL, cost DECIMAL(12,2) NULL, provider VARCHAR(255) NULL,
 created_at TIMESTAMP(6) NOT NULL, updated_at TIMESTAMP(6) NOT NULL,
 CONSTRAINT fk_maintenance_component FOREIGN KEY(component_id) REFERENCES components(id), INDEX idx_maintenance_component(component_id), INDEX idx_maintenance_due(next_due_date)
);
CREATE INDEX idx_component_warranty ON components(warranty_expiry);
CREATE INDEX idx_component_maintenance ON components(next_maintenance_date);
CREATE FULLTEXT INDEX ft_document_text ON documents(original_filename,extracted_text);
