package com.digitalbuildingmemory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@SpringBootApplication
public class DigitalBuildingMemoryApplication {
    public static void main(String[] args) {
        SpringApplication.run(DigitalBuildingMemoryApplication.class, args);
    }
}
