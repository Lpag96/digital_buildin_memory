package com.digitalbuildingmemory.config;
import jakarta.servlet.*; import jakarta.servlet.http.*; import org.slf4j.*; import org.springframework.stereotype.Component; import org.springframework.web.filter.OncePerRequestFilter; import java.io.IOException; import java.util.UUID;
@Component
public class CorrelationIdFilter extends OncePerRequestFilter {
 private static final Logger log=LoggerFactory.getLogger(CorrelationIdFilter.class); public static final String KEY="correlationId";
 @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
  String cid=req.getHeader("X-Correlation-ID"); if(cid==null||cid.isBlank()) cid=UUID.randomUUID().toString(); long start=System.nanoTime(); MDC.put(KEY,cid); res.setHeader("X-Correlation-ID",cid);
  try{log.info("request.start method={} uri={} remote={}",req.getMethod(),req.getRequestURI(),req.getRemoteAddr()); chain.doFilter(req,res); log.info("request.end method={} uri={} status={} durationMs={}",req.getMethod(),req.getRequestURI(),res.getStatus(),(System.nanoTime()-start)/1_000_000);}
  catch(Exception e){log.error("request.failed method={} uri={} durationMs={}",req.getMethod(),req.getRequestURI(),(System.nanoTime()-start)/1_000_000,e); throw e;} finally{MDC.remove(KEY);}
 }
}
