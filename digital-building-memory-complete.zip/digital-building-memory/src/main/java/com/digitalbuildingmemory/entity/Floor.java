package com.digitalbuildingmemory.entity;
import jakarta.persistence.*;
@Entity @Table(name="floors")
public class Floor extends BaseEntity {
 @ManyToOne(optional=false,fetch=FetchType.LAZY) private Building building;
 @Column(nullable=false) private String name; private Integer levelNumber;
 public Building getBuilding(){return building;} public void setBuilding(Building v){building=v;} public String getName(){return name;} public void setName(String v){name=v;} public Integer getLevelNumber(){return levelNumber;} public void setLevelNumber(Integer v){levelNumber=v;}
}
