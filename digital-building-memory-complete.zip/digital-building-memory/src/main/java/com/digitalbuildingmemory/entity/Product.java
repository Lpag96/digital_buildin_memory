package com.digitalbuildingmemory.entity;
import jakarta.persistence.*;
@Entity @Table(name="products")
public class Product extends BaseEntity {
    @ManyToOne(optional=false,fetch=FetchType.LAZY) @JoinColumn(name="organization_id") private Organization organization;
 public Organization getOrganization(){return organization;} public void setOrganization(Organization v){organization=v;}
 @Column(nullable=false) private String manufacturer; @Column(nullable=false) private String name; private String model; private String gtin; private String dppUri;
 public String getManufacturer(){return manufacturer;} public void setManufacturer(String v){manufacturer=v;} public String getName(){return name;} public void setName(String v){name=v;} public String getModel(){return model;} public void setModel(String v){model=v;} public String getGtin(){return gtin;} public void setGtin(String v){gtin=v;} public String getDppUri(){return dppUri;} public void setDppUri(String v){dppUri=v;}
}
