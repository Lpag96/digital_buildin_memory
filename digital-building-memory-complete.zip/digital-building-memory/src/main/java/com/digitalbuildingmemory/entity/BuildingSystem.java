package com.digitalbuildingmemory.entity;
import jakarta.persistence.*;
@Entity @Table(name="building_systems")
public class BuildingSystem extends BaseEntity {
 @ManyToOne(optional=false,fetch=FetchType.LAZY) private Building building;
 @Column(nullable=false) private String name; @Column(nullable=false) private String type;
 public Building getBuilding(){return building;} public void setBuilding(Building v){building=v;} public String getName(){return name;} public void setName(String v){name=v;} public String getType(){return type;} public void setType(String v){type=v;}
}
