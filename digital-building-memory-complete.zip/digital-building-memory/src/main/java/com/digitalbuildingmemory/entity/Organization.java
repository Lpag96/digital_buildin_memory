package com.digitalbuildingmemory.entity;
import jakarta.persistence.*;
@Entity @Table(name="organizations") public class Organization extends BaseEntity {
 @Column(nullable=false) private String name; @Column(nullable=false,unique=true,length=120) private String slug;
 public String getName(){return name;} public void setName(String v){name=v;} public String getSlug(){return slug;} public void setSlug(String v){slug=v;}
}
