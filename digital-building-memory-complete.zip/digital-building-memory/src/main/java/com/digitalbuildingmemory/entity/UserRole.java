package com.digitalbuildingmemory.entity; public enum UserRole { OWNER, ADMIN, EDITOR, VIEWER }
