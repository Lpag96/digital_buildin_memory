package com.digitalbuildingmemory.entity;
import jakarta.persistence.*;
@Entity @Table(name="rooms")
public class Room extends BaseEntity {
 @ManyToOne(optional=false,fetch=FetchType.LAZY) private Floor floor;
 @Column(nullable=false) private String name; private String code;
 public Floor getFloor(){return floor;} public void setFloor(Floor v){floor=v;} public String getName(){return name;} public void setName(String v){name=v;} public String getCode(){return code;} public void setCode(String v){code=v;}
}
