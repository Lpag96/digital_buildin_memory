package com.digitalbuildingmemory.entity;
import jakarta.persistence.*; import java.time.Instant;
@Entity @Table(name="app_users") public class AppUser extends BaseEntity {
 @ManyToOne(optional=false,fetch=FetchType.LAZY) @JoinColumn(name="organization_id") private Organization organization;
 @Column(nullable=false,unique=true,length=320) private String email; @Column(name="password_hash",nullable=false) private String passwordHash;
 @Column(nullable=false) private String displayName; @Enumerated(EnumType.STRING) @Column(nullable=false,length=30) private UserRole role;
 @Column(nullable=false) private boolean enabled=true; private Instant lastLoginAt;
 public Organization getOrganization(){return organization;} public void setOrganization(Organization v){organization=v;} public String getEmail(){return email;} public void setEmail(String v){email=v;} public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String v){passwordHash=v;} public String getDisplayName(){return displayName;} public void setDisplayName(String v){displayName=v;} public UserRole getRole(){return role;} public void setRole(UserRole v){role=v;} public boolean isEnabled(){return enabled;} public void setEnabled(boolean v){enabled=v;} public Instant getLastLoginAt(){return lastLoginAt;} public void setLastLoginAt(Instant v){lastLoginAt=v;}
}
