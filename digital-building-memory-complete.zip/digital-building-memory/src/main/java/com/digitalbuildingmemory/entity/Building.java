package com.digitalbuildingmemory.entity;
import jakarta.persistence.*;
@Entity @Table(name="buildings")
public class Building extends BaseEntity {
    @ManyToOne(optional=false,fetch=FetchType.LAZY) @JoinColumn(name="organization_id") private Organization organization;
    @Column(nullable=false) private String name;
    private String address; private String city; private String country;
    @Column(unique=true) private String externalCode;
    public Organization getOrganization(){return organization;} public void setOrganization(Organization v){organization=v;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getAddress(){return address;} public void setAddress(String v){address=v;}
    public String getCity(){return city;} public void setCity(String v){city=v;}
    public String getCountry(){return country;} public void setCountry(String v){country=v;}
    public String getExternalCode(){return externalCode;} public void setExternalCode(String v){externalCode=v;}
}
