package com.digitalbuildingmemory;
import org.junit.jupiter.api.Test; import static org.junit.jupiter.api.Assertions.*;
class DigitalBuildingMemoryApplicationTests { @Test void sanity(){assertTrue(true);} }
